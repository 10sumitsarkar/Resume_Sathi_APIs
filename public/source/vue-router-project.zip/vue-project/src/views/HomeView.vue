<template>
  <div class="homepage">
    <h1>This is a home page</h1>
  </div>
</template>
<style>
@media (min-width: 1024px) {
  .homepage {
    min-height: 100vh;
    display: flex;
    align-items: center;
  }
}
</style>
