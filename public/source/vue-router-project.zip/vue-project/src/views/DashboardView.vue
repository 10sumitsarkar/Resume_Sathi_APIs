<template>
  <div class="dashboard">
    <div>
    <h1>This is a dashboard page</h1>
        <div>
           <button @click="logout()">Click here to logout</button>
        </div>
    </div>
  </div>
</template>
<script>
export default {
    methods: {
        logout: function(){
            localStorage.setItem('accessToken', '');
            this.$router.push('/login');
        }
    },
}
</script>
<style>
@media (min-width: 1024px) {
  .dashboard {
    min-height: 100vh;
    display: flex;
    align-items: center;
  }
}
</style>
