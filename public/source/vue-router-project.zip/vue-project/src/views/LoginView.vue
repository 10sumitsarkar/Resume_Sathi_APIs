<template>
  <div class="login">
    <div>
    <h1>This is a login page</h1>
        <div>
        <button @click="login()">Click here to login</button>
        </div>
    </div>
  </div>
</template>

<script>
export default {
  methods: {
    login: function() {
      localStorage.setItem(
        "accessToken",
        "fhkdfhdkafh89t89eyt8eerts89r7t89r7t89re"
      );
      this.$router.push("/dashboard");
    },
  },
};
</script>
<style lang="">
</style>


<style>
@media (min-width: 1024px) {
  .login {
    min-height: 100vh;
    display: flex;
    align-items: center;
  }
}
</style>



