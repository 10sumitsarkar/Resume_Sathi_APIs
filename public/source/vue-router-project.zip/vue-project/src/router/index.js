import { createRouter, createWebHistory } from "vue-router";
import HomeView from "../views/HomeView.vue";

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: "/",
      name: "home",
      component: HomeView,
    },
    {
      path: "/login",
      name: "login",
       component: () => import("../views/LoginView.vue"),
    },
    {
      path: "/sign-up",
      name: "sign-up",
       component: () => import("../views/SignUpView.vue"),
    },
    {
      path: "/dashboard",
      name: "dashboard",
       component: () => import("../views/DashboardView.vue"),
    },
    {
      path: "/my-profile",
      name: "my-profile",
       component: () => import("../views/MyProfileView.vue"),
    },
    {
      path: "/about",
      name: "about",
      component: () => import("../views/AboutView.vue"),
    },
  ],
});

// add route name here to make private page
const privateRoutes = [
  'dashboard',
  'my-profile',
];

router.beforeEach((to, from, next) => {
  if (privateRoutes.includes(to.name)) {
    // redirect to login page with next url 
    if (!localStorage.getItem('accessToken')) {
      next(`${'/login?next='}${to.fullPath}`);
    }  
  }

  // redirect to dashboard page if user is already logged in 
  if (to.name === 'login') {
    if (localStorage.getItem('accessToken')) {
      next('/dashboard');
    }
  }
  
  next();
});

export default router;
